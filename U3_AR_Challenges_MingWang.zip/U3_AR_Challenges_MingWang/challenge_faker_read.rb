# WEBD-3008 (254433) Full-Stack Web Development
# U3 - Active Record
# Author: Ming Wang
# Date: 09/29/2024

require_relative 'ar'
require 'faker'

categories = Category.all

categories.each do |category|
  puts "Category: #{category.name}"
  category.products.each do |product|
    puts "  Product: #{product.name}, Price: #{product.price}"
  end
end