# WEBD-3008 (254433) Full-Stack Web Development
# U3 - Active Record
# Author: Ming Wang
# Date: 09/29/2024
require_relative 'ar.rb'

# Find all products with a stock quantity greater than 40
# Add one to the stock quantity of each of these products
high_stock_products = Product.where('stock_quantity > ?', 40)

high_stock_products.each do |product|
  product.increment(:stock_quantity)
  product.save
end