# WEBD-3008 (254433) Full-Stack Web Development
# U3 - Active Record
# Author: Ming Wang
# Date: 09/29/2024

require_relative 'ar.rb'

# Find one of the products created earlier and delete it
product_to_delete = Product.find_by(name: 'Product 1')
product_to_delete.destroy if product_to_delete