# WEBD-3008 (254433) Full-Stack Web Development
# U0 - Challenge Zero (A New Beginning)
# Simple Ruby Program for After Tax Calculation
# Author: Ming Wang
# Date: 09/10/2024

# GST and PST rates
gst_rate = 0.05
pst_rate = 0.07

# Asking user for the subtotal amount
puts "Please enter the subtotal amount: "
sub_total = gets.chomp.to_f # Convert user input to a float

# Calculating the tax amounts
gst_amount = sub_total * gst_rate
pst_amount = sub_total * pst_rate

# Calculating the grand total
grand_total = sub_total + gst_amount + pst_amount

# Displaying the results
puts "Subtotal: $#{sub_total.round(2)}"
puts "PST: $#{pst_amount.round(2)} - 7%"
puts "GST: $#{gst_amount.round(2)} - 5%"
puts "Grand Total: $#{grand_total.round(2)}"

# Adding the message based on grand total
if grand_total <= 5.00
  puts "Pocket Change"
elsif grand_total < 20.00
  puts "Wallet Time"
else
  puts "Charge It!"
end