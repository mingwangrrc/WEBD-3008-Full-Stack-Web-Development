class AboutController < ApplicationController
  def index

  end

  def about
  end
end
