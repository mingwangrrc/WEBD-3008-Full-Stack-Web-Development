require "test_helper"

class TemperatureUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
