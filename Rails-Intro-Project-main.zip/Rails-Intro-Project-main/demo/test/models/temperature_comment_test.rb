require "test_helper"

class TemperatureCommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
