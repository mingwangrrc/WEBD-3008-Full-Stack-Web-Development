# WEBD-3008 (254433) Full-Stack Web Development
# U2 - Ultimate Object-Oriented Ruby Challenge
# 03-leap
# Author: Ming Wang
# Date: 09/21/2024
class Year
  def self.leap?(year)
    return (year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)
  end
end
