# WEBD-3008 (254433) Full-Stack Web Development
# U2 - Ultimate Object-Oriented Ruby Challenge
# 05-grains
# Author: Ming Wang
# Date: 09/21/2024
class Grains
  def self.square(n)
    2 ** (n - 1)
  end

  def self.total
    (2 ** 64) - 1
  end
end
