# WEBD-3008 (254433) Full-Stack Web Development
# U2 - Ultimate Object-Oriented Ruby Challenge
# 02-hello-world-instance
# Author: Ming Wang
# Date: 09/21/2024
class HelloWorld
  def initialize(name)
    @name = name
  end

  def hello(greeting_name = "World")
    "Hello, #{greeting_name}. My name is #{@name}!"
  end
end
