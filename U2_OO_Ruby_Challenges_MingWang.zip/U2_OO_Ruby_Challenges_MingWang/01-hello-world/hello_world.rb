# WEBD-3008 (254433) Full-Stack Web Development
# U2 - Ultimate Object-Oriented Ruby Challenge
# 01-hello-world
# Author: Ming Wang
# Date: 09/21/2024
class HelloWorld
  def self.hello(name = nil)
    if name
      "Hello, #{name}!"
    else
      "Hello, World!"
    end
  end
end

