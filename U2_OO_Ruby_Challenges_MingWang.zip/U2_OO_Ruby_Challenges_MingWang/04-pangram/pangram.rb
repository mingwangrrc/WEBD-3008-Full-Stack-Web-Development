# WEBD-3008 (254433) Full-Stack Web Development
# U2 - Ultimate Object-Oriented Ruby Challenge
# 04-pangram
# Author: Ming Wang
# Date: 09/21/2024
class Pangram
  def self.is_pangram?(str)
    ('a'..'z').all? {|char| str.downcase.include? (char) }
  end
end
